<?php 

	require 'config.php';
	

	$id = $_GET['id'];
	$update = $_POST['update'];

	if(isset($update)){
		

		$sql = 'UPDATE `tasks` SET `task` = ? WHERE `tasks`.`id` = ?';
		$query = $pdo->prepare($sql);
		$query->execute([$update,$id]);
	

		
		header('Location: /index.php');
	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ToDo App</title>


	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container inputTask">
		<h1>ToDo List</h1>

		<form method="post">
			
			<input type="text" name="update" id='update' placeholder="Update row" class="form-control">
			<button type="submit" name="sendTask" class="btn btn-success">Update</button>

		</form>

	</div>



</body>
</html>


