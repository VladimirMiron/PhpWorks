<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ToDo App</title>

	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container inputTask">
		<h1>ToDo List</h1>

		<form action="./task.php" method="post">
			<input type="text" name="task" id="task" placeholder="What need to do" class="form-control">
			
			<button type="submit" name="sendTask" class="btn btn-success">Save</button>

		</form>

	</div>

	<div class="container listTask">
		<?php 
			require 'config.php';

			echo "<ul>";
			$query = $pdo->query('SELECT * FROM `tasks` ORDER BY `id` DESC');
			while ($row = $query -> fetch(PDO::FETCH_OBJ)) {
				echo '<li><b>' .$row->task. '</b>
				<a href="/delete.php?id='.$row->id.'"><button>x</button></a>
				<a href="/update.php?id='.$row->id.'"><button>Edit</button></a>

				</li>';
			}
			echo "</ul>";
		?>
	</div>




</body>
</html>