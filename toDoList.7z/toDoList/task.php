<?php 
	
	$task = $_POST['task'];

	if ($task == '') {

		echo "input empty";
		exit();
		# code...
	}


	require 'config.php';



	$sql = 'INSERT INTO tasks(task) VALUES(:task)';
	$query = $pdo->prepare($sql);
	$query->execute(['task' => $task]);


	header('Location: /');

?>