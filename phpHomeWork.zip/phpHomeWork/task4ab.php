<?php 
	
	require_once 'task1-3.php';

	

	// point 4 (a) insert currencyCode,amount,value directly from xml url


	foreach ($myXml->Valute as $row) {


		$currencyCode = $row->CharCode;
	    $value = $row->Value;
	    $amount = $row->Nominal;
	    



		$sql = "INSERT INTO ExchangeRates(currencyCode,amount,value) VALUES ('" . $currencyCode . "','" . $amount . "','" . $value . "')";

		$result = mysqli_query($conn, $sql);
    
		    if (! empty($result)) {
		        $affectedRow ++;
		    } else {
		        $error_message = mysqli_error($conn) . "\n";
		    }
	


	}

// point 4 (b) extract currencyCode,amount,value and date directly from sql to HTML table

	$sql = "SELECT * FROM `ExchangeRates`";
	$result = mysqli_query($conn, $sql);

	echo '<table border="1">
		<tr>
			<td>currencyCode</td>
			<td>amount</td>
			<td>value</td>
			<td>insert_date</td>
		</tr>';
		

		while ($getValue = mysqli_fetch_assoc($result)){
			echo "<tr>";		
				
				echo '	<td>'.$getValue['currencyCode'].'</td>';
				echo '	<td>'.$getValue['amount'].'</td>';
				echo '	<td>'.$getValue['value'].'</td>';
				echo '	<td>'.$getValue['insert_date'].'</td>';
					
				echo "</tr>";
		}
	echo '</table>';

 ?>





 				


