


<h2 style="text-align: center;">Connecting to xml link with today date, connecting to our BD and create new table ExchangeRates </h2>

<?php 
	ini_set('max_execution_time', 300);
	require 'task1-3.php';
?>


<h2 style="text-align: center;">Insert currencyCode,amount,value directly from xml url and extract currencyCode,amount,value and date directly from sql to HTML table for each date</h2>

<?php 
	ini_set('max_execution_time', 300);
	require 'task4ab.php';
?>


<h2 style="text-align: center;"></h2>

<?php 
	ini_set('max_execution_time', 300);
	require 'task4c.php';
?>


<?php 
	ini_set('max_execution_time', 300);
	require 'task4d.php';
?>


