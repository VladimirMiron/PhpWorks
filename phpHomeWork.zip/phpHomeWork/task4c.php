<?php 

	require_once 'task1-3.php';




	// create new table ExchangeEntity extract values from first table and put changed value in second table

	$sql = "CREATE TABLE ExchangeEntity (
	oper INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	value VARCHAR(30) UNIQUE NOT NULL,
	recvAmount INT(30) NOT NULL,
	finalValue FLOAT(50)
	)";


	if ($conn->query($sql) === TRUE) {
	  echo "Table ExchangeEntity created successfully";
	} else {
	  echo "Error creating table: " . $conn->error;
	}



	$sql = "SELECT * FROM `ExchangeRates`";
	$result = mysqli_query($conn, $sql);



	while ($getValue = mysqli_fetch_assoc($result)){
			$value = $getValue['value'];
			$recvAmount = $getValue['amount'];
			$finalValue = $getValue['amount'] * $getValue['value'];


			$sql = "INSERT INTO ExchangeEntity(value,recvAmount,finalValue) VALUES ('" . $value . "','" . $recvAmount . "','" . $finalValue . "')";

			$resultEntity = mysqli_query($conn, $sql);
    
		    if (! empty($resultEntity)) {
		        $affectedRow ++;
		    } else {
		        $error_message = mysqli_error($conn) . "\n";
		    }
	
	}


 ?>