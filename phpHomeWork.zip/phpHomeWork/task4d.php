<?php 

require_once 'task1-3.php';

$sql = "CREATE TABLE Cash (
	oper INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	currencyCode VARCHAR(30) UNIQUE NOT NULL,
	amount FLOAT(30) NOT NULL,
	insert_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	)";

	if ($conn->query($sql) === TRUE) {
	  echo "Table Cash created successfully";
	} else {
	  echo "Error creating table: " . $conn->error;
	}


	$sqlEntity = "SELECT * FROM `ExchangeEntity`";
	

	$resultEntity = mysqli_query($conn, $sqlEntity);
	


	while ($getValue = mysqli_fetch_assoc($resultEntity)){
			
			$amount = $getValue['finalValue'];
			

			$sqlCash = "INSERT INTO Cash(amount) VALUES ('".$amount."')";

			$resultCash = mysqli_query($conn, $sqlCash);
    
		    if (! empty($resultCash)) {
		        $affectedRow ++;
		    } else {
		        $error_message = mysqli_error($conn) . "\n";
		    }
	
	}






	$sqlCash = "SELECT * FROM `Cash`";
	$resultCash = mysqli_query($conn, $sqlCash);

	echo '<table border="1">
		<tr>
			<td>oper</td>
			<td>currencyCode</td>
			<td>amount</td>
			<td>insert_date</td>
		</tr>';
		

		while ($getValue = mysqli_fetch_assoc($resultCash)){
			echo "<tr>";		
				
				echo '	<td>'.$getValue['oper'].'</td>';
				echo '	<td>'.$getValue['currencyCode'].'</td>';
				echo '	<td>'.$getValue['amount'].'</td>';
				echo '	<td>'.$getValue['insert_date'].'</td>';
					
				echo "</tr>";
		}
	echo '</table>';

	 ?>