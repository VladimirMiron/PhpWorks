
<?php 
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "exchange";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}


	$sql = "CREATE TABLE ExchangeRates (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	currencyCode VARCHAR(30) UNIQUE NOT NULL,
	amount INT(30) NOT NULL,
	value FLOAT(50),
	insert_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	)";

	

	if ($conn->query($sql) === TRUE) {
	  echo "Table ExchangeRates created successfully";
	} else {
	  echo "Error creating table: " . $conn->error;
	}


	echo "<br>";

	$today = date("d.m.Y");

	

	$context  = stream_context_create(array('http' => array('header' => 'Accept: application/xml')));
	$url = 'https://www.bnm.md/ro/official_exchange_rates?get_xml=1&date='.$today.'';
	

	$xml = file_get_contents($url, false, $context);
	$myXml = simplexml_load_string($xml);
	
	
?>