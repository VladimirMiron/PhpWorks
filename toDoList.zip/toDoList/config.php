<?php 
	$acc = 'mysql:host=localhost;dbname=todo';
	$pdo = new PDO($acc, 'root', 'root');
 ?>