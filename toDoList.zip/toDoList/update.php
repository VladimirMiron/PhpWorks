<?php 

	require 'config.php';
	

	$id = $_GET['id'];
	$update = $_POST['update'];
	$priority = $_POST['priority'];


	if(isset($update)){

		$sql = 'UPDATE `tasks` SET `task` = ? , `priority` = ? WHERE `tasks`.`id` = ?';
		$query = $pdo->prepare($sql);
		$query->execute([$update,$priority,$id]);
	

		header('Location: /index.php');
	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ToDo App</title>


	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

	<section class="bodySection">
		<div class="card text-center">
		  	<div class="card-header">
		    	To Do List App
		  	</div>
			<div class="card-body">
				<form method="post">

					<div class="labelForm">
					<input type="text" name="update" id='update' placeholder="Update row" class="form-control">
					<button type="submit" name="sendTask" class="btn btn-success">Update</button>
					</div>

					<div class="labelForm priority">
						<label><input type="radio" id="priority" name="priority" value="1"><b>Most Important</b></label>
						<label><input type="radio" id="priority" name="priority" value="2"><b>More Important</b></label>
						<label><input type="radio" id="priority" name="priority" value="3"><b>Not Important</b></label>
					</div>

				</form>
			</div>
		</div>
	</section>

</body>
</html>


