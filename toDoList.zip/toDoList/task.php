<?php 
	
	$task = $_POST['task'];
	$priority = $_POST['priority'];

	if ($task == '') {

		echo "input empty";
		exit();
		# code...
	}


	require 'config.php';



	$sql = 'INSERT INTO tasks(task,priority) VALUES(?,?)';
	$query = $pdo->prepare($sql);
	$query->execute([$task, $priority]);
	


	header('Location: /');

?>