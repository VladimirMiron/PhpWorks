<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ToDo App</title>

	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<section class="bodySection">
		<div class="card text-center">
		  	<div class="card-header">
		    	To Do List App
		  	</div>
			<div class="card-body">
			    <form action="./task.php" method="post">
				    <div class="labelForm">
						<input type="text" name="task" id="task" placeholder="What need to do" class="form-control">
						<button type="submit" name="sendTask" class="btn btn-success">Save</button>
					</div>
					<div class="labelForm priority">
						<label><input type="radio" id="priority" name="priority" value="1"><b>Most Important</b></label>
						<label><input type="radio" id="priority" name="priority" value="2"><b>More Important</b></label>
						<label><input type="radio" id="priority" name="priority" value="3"><b>Not Important</b></label>
					</div>
					
					

				</form>
			</div>
			<div class="card-footer text-muted">
			    <?php 
				require 'config.php';

				echo "<ul>";
				$query = $pdo->query('SELECT * FROM `tasks` ORDER BY `priority` ASC');
				while ($row = $query -> fetch(PDO::FETCH_OBJ)) {
					
					echo '<li><div><label>'.$row->priority.'</label></div>
					<div>
					<input id="checkbox" type="checkbox">
					<label class="label">' .$row->task. '</label>
					</div>
					<div class="editBtn">
					<a href="/update.php?id='.$row->id.'"><button><i class="fa fa-pencil""></i></button></a>
					<a href="/delete.php?id='.$row->id.'"><button><i class="fa fa-trash"></i></button></a>
					</div>
					</li>';
				}
				echo "</ul>";
			?>
			</div>
		</div>
	</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

		 $('input').click(function() {
	        if($(this).is(':checked')) {
	            $('.todo-item .checker span:not(.checked) input').click();
	        } else {
	            $('.todo-item .checker span.checked input').click();
	        }
	    });

</script>



</body>
</html>